// Template for the Sleeping Tutor practical

import ox.CSO._

object SleepingTutorS{

  var waiting = 0; // number of students waiting
  var tutees = 0; // number of students being taught

  // Three signalling semaphores, for the tutor to wait on, for the students
  // to wait on before a tute, and for students to wait on during a tute; and
  // a mutual exclusion semaphore
  val tutorSleep, studentSleep, endTute, mutex = new Semaphore;
  tutorSleep.down; studentSleep.down; endTute.down;
  // (Note: using the same semaphore for the two student sleeps can lead to
  // difficulties.)

  // Protocol for tutor to wait for students to arrive
  def TutorWait = { tutorSleep.down; }
  
  // Protocol for student to arrive and wait for tutorial
  def Arrive = {
    mutex.down;
    if(waiting==0){  // first student to arrive
      waiting += 1; mutex.up; studentSleep.down; // wait to be woken 
      waiting -= 1; tutees += 1; tutorSleep.up; // wake up tutor
      mutex.up
    }
    else{ // second student to arrive
      tutees += 1; studentSleep.up; // wake up other student, passing baton
    }
  };
  
  // Protocol for students to receive tutorial
  def ReceiveTute = {
    endTute.down; // wait to be woken
    mutex.down; tutees -= 1;
    if(tutees>0) endTute.up; // wake up other student
    mutex.up; 
  };
  
  // Protocol for tutor to end tutorial
  def EndTeach = {
    endTute.up; // wake up first student
  };

  val random = new scala.util.Random;

  def Student(me:String) = proc("Student"+me){
    while(true){
      sleep(random.nextInt(2000));
      println("Student "+me+" arrives");
      Arrive; 
      println("Student "+me+" ready for tutorial");
      ReceiveTute;
      println("Student "+me+" leaves");
    }
  }

  def Tutor = proc("Tutor"){
    while(true){
      println("Tutor waiting for students"); 
      TutorWait;
      println("Tutor starts to teach");
      sleep(1000); 
      println("Tutor ends tutorial"); 
      EndTeach; sleep(1000);
    }
  }

  def System = Tutor || Student("Alice") || Student("Bob")

  def main(args: Array[String]) = System();
}
