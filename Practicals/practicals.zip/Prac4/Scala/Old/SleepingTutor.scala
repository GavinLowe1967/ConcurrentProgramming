// Template for the Sleeping Tutor practical

import ox.CSO._

object SleepingTutor{

  // The aim of the practical is to provide definitions for the following four
  // procedures

  // Protocol for tutor to wait for students to arrive
  def TutorWait = ???
  
  // Protocol for student to arrive and wait for tutorial
  def Arrive = ???
  
  // Protocol for students to receive tutorial
  def ReceiveTute = {};
  
  // Protocol for tutor to end tutorial
  def EndTeach = {};

  val random = new scala.util.Random;

  def Student(me:String) = proc("Student"+me){
    while(true){
      sleep(random.nextInt(2000));
      println("Student "+me+" arrives");
      Arrive; 
      println("Student "+me+" ready for tutorial");
      ReceiveTute;
      println("Student "+me+" leaves");
    }
  }

  def Tutor = proc("Tutor"){
    while(true){
      println("Tutor waiting for students"); 
      TutorWait;
      println("Tutor starts to teach");
      sleep(1000); 
      println("Tutor ends tutorial"); 
      EndTeach; sleep(1000);
    }
  }

  def System = Tutor || Student("Alice") || Student("Bob")

  def main(args: Array[String]) = System();
}
