import ox.CSO._

object SleepingTutorM{

  object Monitor{
    private var waiting = 0; // number of students waiting
    private var tutees = 0; // number of students being taught

    // Protocol for tutor to wait for students to arrive
    def TutorWait = synchronized{
      while(waiting+tutees<2) wait();
    }

    // Protocol for student to arrive and wait for tutorial
    def Arrive = synchronized{
      if(waiting==0){ // first student to arrive
	waiting += 1;
	while(waiting+tutees<2) wait(); 
	waiting -= 1; tutees += 1;
      }
      else{ // second student to arrive
	tutees += 1; notifyAll(); // wake up tutor and other student
      }
    }

    // Protocol for students to receive tutorial
    def ReceiveTute = synchronized{
      while(tutees>0) wait(); // wait for tute to finish
    }

    // Protocol for tutor to end tutorial
    def EndTeach = synchronized{
      tutees = 0; notifyAll(); // wake up the students receiving the tute
    }
  }

  // Export the above, for compatibility with the template
  def TutorWait = Monitor.TutorWait
  def Arrive = Monitor.Arrive
  def ReceiveTute = Monitor.ReceiveTute
  def EndTeach = Monitor.EndTeach

  val random = new scala.util.Random;

  def Student(me:String) = proc("Student"+me){
    while(true){
      sleep(random.nextInt(2000));
      println("Student "+me+" arrives");
      Monitor.Arrive; 
      println("Student "+me+" receives tutorial");
      Monitor.ReceiveTute;
      println("Student "+me+" leaves");
    }
  }

  def Tutor = proc("Tutor"){
    while(true){
      println("Tutor ready to teach"); 
      Monitor.TutorWait;
      println("Tutor starts to teach");
      sleep(1000); 
      println("Tutor ends tutorial"); 
      Monitor.EndTeach; sleep(1000);
    }
  }

  def System = Tutor || Student("Alice") || Student("Bob")

  def main(args: Array[String]) = System();
}

      


      
