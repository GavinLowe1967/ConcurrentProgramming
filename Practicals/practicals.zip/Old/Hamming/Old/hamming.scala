import ox.CSO._
import ox.cso.Components._

/**
        Sketch of a solution to the Hamming problem. The largest Hamming number
        that can be represented as a long is the 12690th. The system deadlocks
        before this -- but not if b1 is of size >= 566. (I haven't checked the 
        exact sizes for b2 and b3, but the system certainly terminates properly if
        they are both of size 400)
        
*/

object hamming
{ 
  def buf(capacity: int, in: ?[long], out: ![long]) = 
  { if (capacity<=1) 
       copy(in, out)
    else
    {
      val mid = Buf[long](capacity)
      ( copy(in, mid) || copy(mid, out) )
    }
  }
  
  def merge(l: ?[long], r: ?[long], out: ![long]) = proc 
  { 
    var lv, rv = 0l    // These buffers hold the most recent inputs on l and r
    
    // Prime the buffers by awaiting input from both channels
    ( proc { lv=l? } || proc { rv=r? } )()
    
    // Output the smaller of the two inputs, and refill the apt buffer.
    repeat
    { if (lv<rv) { out!lv; lv = l? }
      else
      if (rv<lv) { out!rv; rv = r? }
      else 
      { out!lv 
        ( proc { lv=l? } || proc { rv=r? } )()
      }
    }
    l.close
    r.close
    out.close   
  }
  
  /**
        I've not used the stock tee here because I want to
        close down the network when the calculated results
        overflow.
  */
  def tee[T](in: ?[long], l: ![long], r: ![long]) = proc
  { repeat
    { val v = in?;
      if (v<0) stop
      (  proc {l!v}
      ||
         proc {r!v}
      )()
    }
    in.close
    l.close
    r.close
  }
  
  def mul(n: long, in: ?[long], out: ![long]) = map ((m:long)=>m*n) (in, out)
  
  def ham(c1: int, c2:int, c3: int, ext: ![long]) = proc
  { val inl, inr, r1, r2, r3, r4, v3, v1, mo1, v2, mo2, mo3, r5, out = OneOne[long]
    (  prefix(1l)(inl, inr)
    || (tee(out, inl, ext)          withName "t1")
    || (buf(c1,  inr,  r1)          withName "b1")
    || (tee(r1,  v1,   r2)          withName "t2")
    || (buf(c2,  r2,   r3)          withName "b2")
    || (tee(r3,  v2,   r4)          withName "t3")
    || (buf(c3,  r4,   v3)          withName "b3")
    || (mul(2l, v1, mo1)            withName "x2")
    || (mul(3l, v2, mo2)            withName "x3")
    || (mul(5l, v3, mo3)            withName "x5")
    || (merge(mo1, mo2, r5)         withName "mg1")
    || (merge(r5,  mo3, out)        withName "mg2")
    )()
  }
  
  def main(args: Array[String])
  { val hams = OneOne[long]
    var c1, c2, c3 = 1
    for (arg<-args) 
        if (arg.startsWith("-c1=")) c1 = arg.substring(4).toInt else
        if (arg.startsWith("-c2=")) c2 = arg.substring(4).toInt else
        if (arg.startsWith("-c3=")) c3 = arg.substring(4).toInt else
        if (arg.matches("[0-9]+"))  { c3 = arg.toInt; c1=c3; c2=c3 } 
    (  ham(c1, c2, c3, hams) 
    || proc 
       { import ox.Format._
         var n = 0
         repeat { n=n+1; printf("%-6d %12d%n", n, hams?) }
       }
    )()
  }
}



