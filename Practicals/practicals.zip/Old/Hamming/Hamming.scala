import ox.CSO._
import ox.cso.Components._

object Hamming{
  // Flush a channel
  def flush[T](in: ?[T]) = { repeat{ in?; () } }

  // Tee components, giving two outputs
  def Tee[T](in: ?[T], out1: ![T], out2: ![T]) = proc{
    repeat{ val v = in? ; out1!v ; out2!v }
    out1.close ; out2.close; flush(in);
  }

  // Merge two non-empty ascending streams
  def Merge(left: ?[Int], right: ?[Int], out: ![Int], id: Int) = proc("Merge"){
    // Invariant: l is last value read from left; r is last value read from
    // right
    def Report(v:Int) = if(false)println("Merge "+id+" outputs "+v);
    var l = left?; var r = right?;
    repeat{
      if(l<r){ out!l; Report(l); l=left? }
      else if(l==r){ out!l; Report(l); l=left?; r=right?; }
      else{ out!r; Report(r); r=right? }
    }
    // Flush inputs
    serve( left ==> { x => () } | right ==> { x => () } )
    out.close
  }

  // Sent t to out, then copy from in to out
  def Prefix[T](t:T)(in: ?[T], out: ![T]) = proc{ 
    out!t; repeat{ out!(in?) }; 
    flush(in); out.close
  }

  // Map function f over input stream
  def Map[I,O] (f: I => O) (in: ?[I], out: ![O]) = proc{
    repeat { out!(f(in?)) };
    flush(in); out.close;
  }

  /**
  The diagram below illustrates how we'll name the channels and components

  -->[Tee1]--h3-->[Tee2]--h5-->[*5]
  |    |            |           |
  h1   h2           h4          t5
  |    |            |           |
  |    V            V           |
  |   [*2]         [*3]         |
  |    |            |           |
  |    t2           t3          |
  |    |            |           |
  |    |            V           V
  |    |--------[Merge1]-m1->[Merge2]
  |                             |
  |--[Tee0]<-h0-[Prefix 1]<-m2---   

  */

  // Put the system together, as in the diagram, giving buffering buf to each
  // channel
  def System(out: ![Int], buf:Int) = {
    val h0, h1, h2, h3, h4, h5, m1, m2 = OneOne[Int];  
    val t2, t3, t5 = if(buf==0) OneOne[Int] else Buf[Int](buf);
    (Tee(h0, out, h1) withName "Tee0") || 
    (Prefix(1)(m2, h0) withName "Prefix") || 
    (Tee(h1, h2, h3) withName "Tee1") || 
    (Map((x:Int) => 2*x)(h2,t2) withName "map (*2)") || 
    (Tee(h3, h4, h5) withName "Tee2") || 
    (Map((x:Int) => 3*x)(h4,t3) withName "map (*3)") || 
    (Merge(t2, t3, m1, 1) withName "Merge1") ||
    (Map((x:Int) => 5*x)(h5,t5) withName "map (*5)") || 
    (Merge(t5, m1, m2, 2) withName "Merge2")
  }

  // Print N values from report onto the console
  def Monitor(report: ?[Int], N: Int) = proc{
    for(i <- 1 to N){ println(i+": "+(report?)); }
    report.close;
  }

  def main(args: Array[String]) = { 
    val report = OneOne[Int]; 
    // Take amount of buffering from command line; default 0
    val buf = if(args.length>0){Integer.valueOf(args(0)).intValue()} else 0; 
    (System(report, buf) || Monitor(report, 1000))()
  }

}

/** 

With no buffering, this deadlocks after outputting 1, 2, 3, 4, 5, 6.  (The
precise place of deadlock may vary, depending upon the order in which the Tees
do their outputs, and the order in which the Merges do their inputs.)

- Tee0 is waiting to output 6 on h1

- Prefix is waiting to output 8 on h0

- Merge2 is waiting to output 9 on m2

- map (*5) is waiting to output 15 on t5

- Merge1 is waiting to output 10 on m1

- map (*3) is waiting to input on h4 (its last output was 12)

- map (*2) is waiting to input on h2 (its last output was 10)

- Tee2 is waiting to output 4 on h5

- Tee1 is wating to output 5 on h3

With buffering of at least 224, we find the 1000th Hamming number is 51200000.

To get the network to terminate when Monitor closes report, we need to get all
components to flush their input streams, then close their output stream.

*/
