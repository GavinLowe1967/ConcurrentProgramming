import ox.CSO._;

object Life{
  val N = 80; // size of the grid
  val a =  new Array[Array[Boolean]](N,N);

  val display = new Display(N,a); // set up display

  // successor and predecessor
  def succ(k:Int) = (k+1)%N;
  def pred(k:Int) = (k+N-1)%N;

  val p = 8; // number of processes
  assert(N%p == 0);
  val height = N/p; // height of one strip

  // Barrier for synchronisation
  val barrier = new Barrier(p)
  
  // Worker to handle rows me*height until (me+1)*height; also holds rows
  // me*height and (me+1)*height as read-only
  def Worker(me: Int) = proc{
    val start = me*height;
    val end = (me+1)*height;

    // Helper function to give 1 iff cell (i,j) is alive
    def f(i:Int,j:Int) = if(a(i)(j)) 1 else 0;

    // main loop
    while(true){
      sleep(500);
      val newA = new Array[Array[Boolean]](height,N);
      // store new value for a(i)(j) in newA(i-start)(j)
      for(i <- start until end; j <- 0 until N){
	val neighbours = // number of live neighbours
	  f(pred(i),pred(j)) + f(pred(i),j) + f(pred(i),succ(j)) +
	  f(i, pred(j))      +                f(i,succ(j)) +
	  f(succ(i),pred(j)) + f(succ(i),j) + f(succ(i),succ(j))
	newA(i-start)(j) = (a(i)(j) && neighbours==2) || neighbours==3;
      }
      barrier.sync;
      for(i <- start until end) a(i) = newA(i-start);
      barrier.sync;
      if(me==0) display.draw; // could fork this off
    }
  }

  def System = || (for (i <- 0 until p) yield Worker(i));

  // Various constructions of initial configurations
  
  // Produce initial configuration from list of strings, where each string
  // corresponds to one row, and each "*" corresponds to a live cell
  def ParseStrings(ss:List[String])(x:Int, y:Int){
    var y1=y;
    for(s <- ss){
      var x1 = x;
      for(c <- s){ if(c=='*') a(x1)(y1) = true; x1 = succ(x1); }
      y1 = succ(y1);
    }
  }

  // Make glider centred at (pred(x),y); the "pred" is for
  // backwards-compatability
  def MakeGlider(x:Int,y:Int) = 
    ParseStrings("***"::"*.."::".*."::Nil)(pred(x), y);

  // Make block at (x,y)
  def MakeBlock = ParseStrings("**"::"**"::Nil) _;

  // Initialise randomly
  def MakeRandom{
    val random = new scala.util.Random;
    for(y <- 0 until N*N/5) a(random.nextInt(N))(random.nextInt(N)) = true;
  }

  // Create the following pattern, centred at (x,y)
  // XXX.X
  // X....
  // ...XX
  // .XX.X
  // X.X.X
  // This is supposed to lay a sequence of blocks, but doesn't seem to work
  def BlockLayer1 = 
    ParseStrings("***.*"::"*...."::"...**"::".**.*"::"*.*.*"::Nil) _;

  // Gosper gun, which fires off a sequence of gliders
  def GosperGun = 
    ParseStrings(
      "........................*..........."::
      "......................*.*..........."::
      "............**......**............**"::
      "...........*...*....**............**"::
      "**........*.....*...**.............."::
      "**........*...*.**....*.*..........."::
      "..........*.....*.......*..........."::
      "...........*...*...................."::
      "............**......................"::Nil
    ) _;
 
  def main(args:Array[String]) = {
    // parse argument to choose option
    if(args.length>0){
      if(args(0)=="1"){ MakeGlider(35,30); MakeBlock(27,27); } 
      // quickly reaches fixed point 
      else if(args(0)=="2"){ MakeGlider(34,30); MakeBlock(27,27); }
      // after long history, reaches oscillating state
      else if(args(0)=="3"){ MakeGlider(33,30); MakeBlock(27,27); }
      // quickly dies out
      else if(args(0)=="4"){ MakeGlider(32,30); MakeBlock(25,25); }
      // quickly dies out
      else if(args(0)=="5"){ MakeGlider(31,30); MakeBlock(25,25); }
      // quickly dies out
      else if(args(0)=="6"){ MakeGlider(30,30); MakeBlock(25,25); }
      // quickly dies out
      else if(args(0)=="7"){ MakeGlider(29,30); MakeBlock(25,25); }
      // quickly dies out
      else if(args(0)=="8"){ MakeGlider(28,30); MakeBlock(25,25); }
      // quickly dies out
      else if(args(0)=="9"){ MakeGlider(27,30); MakeBlock(25,25); }
      // after long history, reaches oscillating state; same as 2?
      else if(args(0)=="10"){ MakeGlider(26,30); MakeBlock(25,25); }
      // quickly reaches fixed point; same as 1?
      else if(args(0)=="11"){ MakeGlider(25,30); MakeBlock(25,25); }
      // quickly reaches fixed point
      else if(args(0)=="12"){ MakeGlider(24,30); MakeBlock(25,25); }
      // glider misses target
      else if(args(0)=="bl1"){ BlockLayer1(25,25); }
      // block laying machine; this doesn't seem to work
      else if(args(0)=="gg"){ GosperGun(25,25); }
      else MakeRandom
    }
    else MakeRandom

    display.draw;
    System();
  }
}

/**

An easy mistake to make (ok, I made it) is to forget to initialise newA as a
new array -- reusing the old one means that there is sharing between a and
newA.

*/
