// Dining Philosophers

import ox.CSO._

object PhilsButler{
  val N = 5; // Number of philosophers

  val random = new scala.util.Random;

  // Simulate basic actions
  def Eat = sleep(500);
  def Think = 800; // sleep(random.nextInt(800)); 
  def Pause = sleep(500);
 
  // channel to report what's happening  
  val report = ManyOne[String]; 

  // Channels to communicate with the butler 
  val sit = ManyOne[Unit]
  val stand = ManyOne[Unit]
  // These could be passed as parameters to Phil, but it's easier to treat
  // them as global variables

  // A single philosopher
  def Phil(me : Int, left: ![String], right: ![String]) = proc("Phil"+me){
    repeat{
      Think;
      sit!(); report!(me+" sits"); Pause;
      left!"pick"; report!(me+" picks up left fork"); Pause;
      right!"pick"; report!(me+" picks up right fork"); Pause;
      report ! (me+" eats"); Eat;
      left!"drop"; Pause;
      right!"drop"; Pause;
      stand!(); report ! (me+" leaves")
    }
  }

  // A single fork
  def Fork(me : Int, left: ?[String], right: ?[String]) = proc("Fork"+me){
    serve(
      left --> {
	val x = left?; assert(x=="pick");
	val y = left?; assert(y=="drop");
      }
      | right --> {
	val x = right?; assert(x=="pick");
	val y = right?; assert(y=="drop");
      }
    )
  }

  // The butler
  def Butler(sit: ?[Unit], stand: ?[Unit]) = proc("Butler"){
    var seated = 0; // Number currently seated
    serve(
      (seated<4 &&& sit) --> { sit?; seated+=1; }
      | stand --> {stand?; seated-=1; }
    )
  }

  // Copy messages from report onto the console
  def TheConsole : PROC = proc{ repeat{ Console.println(report?) } }

  // Channels to pick up and drop the forks:
  val philToLeftFork, philToRightFork = OneOne[String](5) 
  // philToLeftFork(i) is from Phil(i) to Fork(i);
  // philToRightFork(i) is from Phil(i) to Fork((i-1)%N)


  // Put the components together
  def AllPhils : PROC = || ( 
    for (i <- 0 until N) yield 
      Phil( i, philToLeftFork(i), philToRightFork(i) ) 
  )

  def AllForks : PROC = || ( 
    for (i <- 0 until N) yield 
      Fork( i, philToRightFork((i+1)%N), philToLeftFork(i) ) 
  )

  def System : PROC = AllPhils || AllForks || Butler(sit,stand) || TheConsole

  // And run it
  def main(args : Array[String]) = System() 
}

  
