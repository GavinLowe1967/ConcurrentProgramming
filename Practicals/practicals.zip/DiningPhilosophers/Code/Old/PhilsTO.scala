// Dining Philosophers

import ox.CSO._

object PhilsTO{
  val N = 5; // Number of philosophers

  val random = new scala.util.Random;
  val PICK = 0; val DROP = 1; 

  // Simulate basic actions
  def Eat = sleep(500);
  def Think = sleep(500+random.nextInt(200)); 
  def Pause = sleep(2000);
 
  val report = ManyOne[String]; 

  // A single philosopher
  def Phil(me : Int, left: ![Int], right: ![Int]) = proc("Phil"+me){
    repeat{
      Think; report!(me+" sits"); // Pause;
      // try to get both forks
      var done = false;
      while(!done){
	left!PICK; report!(me+" picks up left fork"); Pause;
	alt(
	  right -!-> { 
	    right!PICK; done = true; report!(me+" picks up right fork"); 
	  }
	  | 
	  after(1000) ==> { 
	    left!DROP; report!(me+" replaces left fork and retries"); 
	    sleep(random.nextInt(2000));
	  }
	)
      }
      // Now got both forks
      // Pause; 
      report ! (me+" eats"); Eat;
      left!DROP; Pause;
      right!DROP; Pause;
      report ! (me+" leaves")
    }
  }

  // A single fork
  def Fork(me : Int, left: ?[Int], right: ?[Int]) = proc("Fork"+me){
    serve(
      left -?-> {
	val x = left?; assert(x==PICK);
	val y = left?; assert(y==DROP);
      }
      | right -?-> {
	val x = right?; assert(x==PICK);
	val y = right?; assert(y==DROP);
      }
    )
  }

  // Copy messages from report onto the console
  def TheConsole : PROC = proc{ repeat{ Console.println(report?) } }

  // Channels to pick up and drop the forks:
  val philToLeftFork, philToRightFork = OneOne[Int](5) 
  // philToLeftFork(i) is from Phil(i) to Fork(i);
  // philToRightFork(i) is from Phil(i) to Fork((i-1)%N)


  // channel to report what's happening  // Put the components together
  def AllPhils : PROC = || ( 
    for (i <- 0 until N) yield 
      Phil( i, philToLeftFork(i), philToRightFork(i) ) 
  )

  def AllForks : PROC = || ( 
    for (i <- 0 until N) yield 
      Fork( i, philToRightFork((i+1)%N), philToLeftFork(i) ) 
  )

  def System : PROC = AllPhils || AllForks || TheConsole

  // And run it
  def main(args : Array[String]) = System() 
}

  
