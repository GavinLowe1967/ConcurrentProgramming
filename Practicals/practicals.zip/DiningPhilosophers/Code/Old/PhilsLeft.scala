// Dining Philosophers, with one right hander

import ox.CSO._

object PhilsLeft{
  val N = 5; // Number of philosophers

  val random = new scala.util.Random;

  // Simulate basic actions
  def Eat = sleep(500);
  def Think = 800; // sleep(random.nextInt(800)); 
  def Pause = sleep(500);
 
  // channel to report what's happening  
  val report = ManyOne[String]; 

  // A single philosopher; 
  // leftHanded is true if this philosopher is left handed
  def Phil(me : Int, left: ![String], right: ![String], leftHanded: Boolean) 
  = proc("Phil"+me){
    // Procedures to pick up each fork
    def PickLeft = { 
      left!"pick"; report!(me+" picks up left fork"); Pause; 
    }
    def PickRight = { 
      right!"pick"; report!(me+" picks up right fork"); Pause; 
    }

    repeat{
      Think;
      report!(me+" sits"); Pause;
      if(leftHanded){ PickLeft; PickRight; }
      else{ PickRight; PickLeft; }
      report ! (me+" eats"); Eat;
      left!"drop"; Pause;
      right!"drop"; Pause;
      report ! (me+" leaves")
    }
  }

  // A single fork
  def Fork(me : Int, left: ?[String], right: ?[String]) = proc("Fork"+me){
    serve(
      left --> {
	val x = left?; assert(x=="pick");
	val y = left?; assert(y=="drop");
      }
      | right --> {
	val x = right?; assert(x=="pick");
	val y = right?; assert(y=="drop");
      }
    )
  }

  // Copy messages from report onto the console
  def TheConsole : PROC = proc{ repeat{ Console.println(report?) } }

  // Channels to pick up and drop the forks:
  val philToLeftFork, philToRightFork = OneOne[String](5) 
  // philToLeftFork(i) is from Phil(i) to Fork(i);
  // philToRightFork(i) is from Phil(i) to Fork((i-1)%N)


  // Put the components together
  // Arrange for Philosopher 0 to be right-handed
  def AllPhils : PROC = || ( 
    for (i <- 0 until N) yield 
      Phil( i, philToLeftFork(i), philToRightFork(i), i!=0 ) 
  )

  def AllForks : PROC = || ( 
    for (i <- 0 until N) yield 
      Fork( i, philToRightFork((i+1)%N), philToLeftFork(i) ) 
  )

  def System : PROC = AllPhils || AllForks || TheConsole

  // And run it
  def main(args : Array[String]) = System() 
}

  
