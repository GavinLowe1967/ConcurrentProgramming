// Dining Philosophers, using timeouts to avoid deadlocks

// A philosopher will time out if it is unable to obtain its second fork. 

// In order to achieve this, we have separate pick and drop channels, and use
// ManyOne channels (from philosophers to forks)

import ox.CSO._

object PhilsTO{
  val N = 5; // Number of philosophers

  val random = new scala.util.Random;

  // Simulate basic actions
  def Eat = sleep(2000);
  def Think = sleep(800); // random.nextInt(800)); 
  def Pause = sleep(500);
  def RandomPause = sleep(500); // sleep(500+random.nextInt(2000)); 
 
  // channel to report what's happening  
  val report = ManyOne[String]; 

  // A single philosopher
  def Phil(me : Int, leftPick: ![Unit], rightPick: ![Unit], 
	   leftDrop: ![Unit], rightDrop: ![Unit]) = proc("Phil"+me){
    repeat{
      Think;
      report!(me+" sits"); Pause;
      var done = false; // Have we got both forks?
      while(! done){
	// Get left fork
	leftPick!(); report!(me+" picks up left fork"); Pause;
	// Try to get right fork
	alt(
	  rightPick -!-> {
	    rightPick!(); report!(me+" picks up right fork"); Pause;
	    done = true;
	  }
	  | after(100) --> {
	    report!(me+" failed to get right fork, replaces left fork"); 
	    leftDrop!(); RandomPause
	  }
	)
      }
      // Have now got both forks
      report ! (me+" eats"); Eat;
      leftDrop!(); Pause; rightDrop!();
      report ! (me+" drops forks and leaves")
    }
  }

  // A single fork
  def Fork(me : Int, pick: ?[Unit], drop: ?[Unit]) = proc("Fork"+me){
    repeat{ pick?; drop?; }
  }

  // Copy messages from report onto the console
  def TheConsole : PROC = proc{ repeat{ Console.println(report?) } }

  // Channels to pick up and drop the forks, indexed by the fork identity:
  val forkPick, forkDrop = ManyOne[Unit](5) 

  // Put the components together
  def AllPhils : PROC = || ( 
    for (i <- 0 until N) yield 
      Phil( i, forkPick(i), forkPick((i+N-1)%N), 
	    forkDrop(i), forkDrop((i+N-1)%N) ) 
  )

  def AllForks : PROC = || ( 
    for (i <- 0 until N) yield Fork( i, forkPick(i), forkDrop(i) ) 
  )

  def System : PROC = AllPhils || AllForks || TheConsole

  // And run it
  def main(args : Array[String]) = System() 
}

  
